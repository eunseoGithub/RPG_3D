﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/*
 * BGMManager
 * 배경음악 관리
 */
public class BGMManager : MonoBehaviour
{
    public static BGMManager Instance { get; private set; }

    public AudioClip bgm;
    public AudioClip bossBgm;
    AudioSource audioSource;

    private void Awake()
    {
        Instance = this;
    }

    private void Start()
    {
        audioSource = GetComponent<AudioSource>();
        audioSource.volume = 0.5f;
        audioSource.loop = true;

        PlaySound(bgm);
    }

    public void PlaySound(AudioClip audioClip)
    {
        audioSource.clip = audioClip;
        audioSource.Play();
    }
}
